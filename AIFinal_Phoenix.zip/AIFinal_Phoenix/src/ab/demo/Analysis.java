package ab.demo;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.List;

import ab.demo.other.ActionRobot;
import ab.demo.other.Shot;

public class Analysis {
    private List<Rectangle> woodObstacles;
    private List<Rectangle> iceObstacles;
    private List<Rectangle> stoneObstacles;
    private List<Rectangle> pigs;
    
    public Analysis() {
        System.out.println("Created Analysis-Object");
    }
    
    public void addWoodenObstacles(List<Rectangle> obstacles) {
        this.woodObstacles = obstacles;
    }
    
    public void addIceObstacles(List<Rectangle> obstacles) {
        this.iceObstacles = obstacles;
    }
    
    public void addStoneObstacles(List<Rectangle> obstacles) {
        this.stoneObstacles = obstacles;
    }
    
    public void addPigs(List<Rectangle> pigs) {
        this.pigs = pigs;
    }

    private LinkedList<Rectangle> getJointObstacles() {
        LinkedList<Rectangle> obstacles = new LinkedList<Rectangle>();
        obstacles.addAll(this.woodObstacles);
        obstacles.addAll(this.iceObstacles);
        obstacles.addAll(this.stoneObstacles);

        return obstacles;
    }

    private Rectangle getClusterBorder(LinkedList<Rectangle> cluster) {
        if(cluster == null || cluster.size() < 1) return null;
        
        double top = Double.MAX_VALUE;
        double bottom = Double.MIN_VALUE;
        double left = Double.MAX_VALUE;
        double right = Double.MIN_VALUE;
        for(Rectangle i : cluster) {
            if(i.getY() < top) top = i.getY();
            if(i.getY()    + i.getHeight() > bottom) bottom = i.getY() + i.getHeight();
            if(i.getX()    + i.getWidth() > right) right = i.getX() + i.getWidth();
            if(i.getX()    < left) left = i.getX();            
        }
        System.out.println("- contains "+cluster.size()+" rects. bounds are left:"+(int)left+" right:"+(int)right+" top:"+(int)top+" bottom:"+(int)bottom);
        return new Rectangle((int) left, (int) top, (int) (right-left), (int) (bottom-top));
    }

    private int countPigsInCluster(LinkedList<Rectangle> cluster) {
        Rectangle clusterBorder = this.getClusterBorder(cluster);
        int pigCount = 0;
        for(Rectangle i : this.pigs) {
            if(clusterBorder.contains(i)) {
                pigCount++;
            }
        }
        
        return pigCount;
    }
    
    private LinkedList<LinkedList<Rectangle>> getClusters() {
        int TRESHOLD = 4;

        if(this.woodObstacles == null && this.iceObstacles == null && 
           this.stoneObstacles == null){
            return null;
        } else {
            LinkedList<Rectangle> obstacles = this.getJointObstacles();
            
            LinkedList<LinkedList<Rectangle>> clusterlist = new LinkedList<LinkedList<Rectangle>>();
            clusterlist.add(new LinkedList<Rectangle>());
            clusterlist.getFirst().add(obstacles.poll());
            boolean extendedCluster;
            while(obstacles.size() > 0) { //as long as not all obstacles are clustered, cluster them
                extendedCluster = false; //indicates if one of the clusters were extended
                for(int i=0; i<clusterlist.size(); ++i) { //iterate over all currently existing clusters
                    for(int j=0; j<clusterlist.get(i).size(); ++j) { //search if there is an obstacle that belongs to this cluster
                        Rectangle dummy = new Rectangle(clusterlist.get(i).get(j));
                        dummy.grow(TRESHOLD, TRESHOLD);
                        for(int k=0; k<obstacles.size(); ++k) { //iterate over remaining obstacles
                            if(obstacles.get(k).intersects(dummy)) { //if there is an obstacle belonging to this cluster
                                clusterlist.get(i).add(obstacles.get(k)); //add the obstacle
                                obstacles.remove(k);
                                
                                //start searching again
                                j = clusterlist.get(i).size()-1;
                                i = clusterlist.size()-1;
                                extendedCluster = true;
                                break;
                            }
                        }
                    }
                }
                
                //if none of the remaining obstacles belong to an existing cluster
                if(!extendedCluster) {
                    //create a new cluster
                    LinkedList temp = new LinkedList<Rectangle>();
                    temp.add(obstacles.poll());
                    clusterlist.add(temp);
                }
            }
            
            return clusterlist;
        }
    }


 

	public LinkedList<Rectangle> targetsInCluster(LinkedList<Rectangle> cluster){
	
		LinkedList<Rectangle> targets = new LinkedList<Rectangle>();
		targets.add(cluster.poll());		
		while(cluster.size()>0){
			for(int i=0; i<targets.size(); i++) {
				Rectangle a = new Rectangle(targets.get(i));
				Rectangle b = new Rectangle(cluster.getFirst());
				if((a.getY()+a.getHeight() < b.getY()) || (a.getY() > b.getY()+b.getHeight())){
					targets.add(cluster.poll());
				}
				else {
					if(a.getX() < b.getX()){
						cluster.pop();
					}
					else {
						targets.add(cluster.poll());
						targets.pop();
					}
				}
			}
		}
		return targets;
	
	}

    
    public List<Point> weakSpotsForRedBird() {
        System.out.println("Searching weak spots for red birds");
        
        //do clustering
        LinkedList<LinkedList<Rectangle>> clusters = getClusters();
        System.out.println("Found "+clusters.size()+" cluster(-s)");
        
        //search the cluster containing the most pigs
        int pigs=0, index=0;
        for(int i=0; i<clusters.size(); ++i) {
            System.out.println("CLUSTER #"+i+":");
            int numberOfPigs = this.countPigsInCluster(clusters.get(i));
            System.out.println("- cluster contains "+numberOfPigs+" pigs\n");
            if(numberOfPigs > pigs) {
                pigs = numberOfPigs;
                index = i;
            }            
        }
        
        //if a cluster contains pigs, attack cluster, otherwise attack first pig
        LinkedList<Point> weakSpots = new LinkedList<Point>();
        if(pigs > 0) {
            System.out.println("Cluster #"+index+" contains most of the pigs, attack it!");
            Rectangle promisingClustersBoundingBox = this.getClusterBorder(clusters.get(index));
            Point center = new Point((int) (promisingClustersBoundingBox.getX() +
                                       (promisingClustersBoundingBox.getWidth()/2)),
                                       (int) (promisingClustersBoundingBox.getY() +
                                       (promisingClustersBoundingBox.getHeight()/2)));
            weakSpots.add(center);
            System.out.println("using weak structure as target point " + center);
        } else if(pigs == 0 && this.pigs.size() > 0) {
            System.out.println("No cluster contains pigs, attack pig directly!");
            Rectangle firstPig = this.pigs.get(0);
            Point target = new Point((int) firstPig.getX(), (int) firstPig.getY());
            weakSpots.add(target);
            System.out.println("using pig as target point "+target);
        }
        return weakSpots;
    }
    
    public List<Point> weakSpotsForYellowBird() {
        return null;
    }
    
    public List<Point> weakSpotsForBlueBird() {
        return null;
    }
}
