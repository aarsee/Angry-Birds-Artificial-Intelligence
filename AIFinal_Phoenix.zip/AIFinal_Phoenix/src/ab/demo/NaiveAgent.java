/*****************************************************************************
 ** ANGRYBIRDS AI AGENT FRAMEWORK
 ** Copyright (c) 2014, XiaoYu (Gary) Ge, Stephen Gould, Jochen Renz
 **  Sahan Abeyasinghe,Jim Keys,  Andrew Wang, Peng Zhang
 ** All rights reserved.
 **This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
 **To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
 *or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.
 *****************************************************************************/
package ab.demo;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import ab.demo.other.ActionRobot;
import ab.demo.other.Shot;
import java.util.LinkedList;
import ab.planner.TrajectoryPlanner;
import ab.utils.StateUtil;
import ab.utils.ABUtil;
import ab.vision.*;
import ab.vision.ABObject;
import ab.vision.GameStateExtractor.GameState;
import ab.vision.Vision;
import ab.vision.VisionMBR;

public class NaiveAgent implements Runnable {

	private ActionRobot aRobot;
	private Random randomGenerator;
	public int currentLevel = 1;
	public static int time_limit = 12;
	private Map<Integer,Integer> scores = new LinkedHashMap<Integer,Integer>();
	TrajectoryPlanner tp;
	private boolean firstShot;
	private Point prevTarget;
	// a standalone implementation of the Naive Agent
	public NaiveAgent() {
		
		aRobot = new ActionRobot();
		tp = new TrajectoryPlanner();
		prevTarget = null;
		firstShot = true;
		randomGenerator = new Random();
		// --- go to the Poached Eggs episode level selection page ---
		ActionRobot.GoFromMainMenuToLevelSelection();

	}
    static int a;
	// run the client
	public void run() {

            aRobot.loadLevel(currentLevel);
            while (true) {
                GameState state = solve();
                if (state == GameState.WON) {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    int score = StateUtil.getScore(ActionRobot.proxy);
                    if (!scores.containsKey(currentLevel))
                        scores.put(currentLevel, score);
                    else {
                        if (scores.get(currentLevel) < score)
                            scores.put(currentLevel, score);
                    }
                    int totalScore = 0;
                    for (Integer key : scores.keySet()) {

                        totalScore += scores.get(key);
                        System.out.println(" Level " + key
                                + " Score: " + scores.get(key) + " ");
                    }
                    System.out.println("Total Score: " + totalScore);
                        aRobot.loadLevel(++currentLevel);
                    
                    // make a new trajectory planner whenever a new level is entered
                    tp = new TrajectoryPlanner();

                    // first shot on this level, try high shot first
                    firstShot = true;
                } else if (state == GameState.LOST) {
                    System.out.println("Restart");
                    aRobot.restartLevel();
                } else if (state == GameState.LEVEL_SELECTION) {
                    System.out
                            .println("Unexpected level selection page, go to the last current level : "
                                    + currentLevel);
                    aRobot.loadLevel(currentLevel);
                } else if (state == GameState.MAIN_MENU) {
                    System.out
                            .println("Unexpected main menu page, go to the last current level : "
                                    + currentLevel);
                    ActionRobot.GoFromMainMenuToLevelSelection();
                    aRobot.loadLevel(currentLevel);
                } else if (state == GameState.EPISODE_MENU) {
                    System.out
                            .println("Unexpected episode menu page, go to the last current level : "
                                    + currentLevel);
                    ActionRobot.GoFromMainMenuToLevelSelection();
                    aRobot.loadLevel(currentLevel);
                }

            }



    }
    public int FindTapInterval(BufferedImage screenshot, Point pt, Rectangle sling, Point _tpt)
		{
		Vision vision = new Vision(screenshot);
		VisionMBR MBR = new VisionMBR(screenshot);
		List<ABObject> pigs = vision.findPigsMBR();
		List<ABObject> blocks = MBR.findBlocks();
		for(ABObject blk : blocks)
		{
			if(blk.getX() < _tpt.x)
			{
				if(blk.getY() <= _tpt.y && blk.getY() + blk.height >= _tpt.y)
				_tpt.x = (int)blk.getX();
			}
		}
		List<Point> trajectory = tp.predictTrajectory(sling, pt);
		List<Point> traj_to_target = new LinkedList<Point>();
		int k= 0;
		double per = 0.10;
		switch (aRobot.getBirdTypeOnSling())
		{
			case YellowBird:
			per = 0.18 ; 
			break; 
			case BlueBird:
			per = 0.1; 
			break; 
			case BlackBird:
			per = 0.25; 
			break;
			case WhiteBird:
			per = 0.15; 
			break;  
			default:
			per = 0.1;
		}
		for(k= 0; k<trajectory.size(); k++)
		{
			if(trajectory.get(k).getX() <= (_tpt.x - per*(_tpt.x - sling.x)))
			{
				traj_to_target.add(trajectory.get(k));
			}
			else
				break;
		}
		Point tapPoint = new Point();
		tapPoint.x =(int) trajectory.get(k).getX();
		tapPoint.y = (int) trajectory.get(k).getY();
		double tap_interval = ((double)traj_to_target.size()/(double)trajectory.size())*100;
		int taptimefinal = tp.getTimeByDistance(sling, pt, tapPoint);
		return taptimefinal;
		}


	private double distance(Point p1, Point p2) {
		return Math
				.sqrt((double) ((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y)
						* (p1.y - p2.y)));
	}

	public GameState solve()
	{

        boolean if_blue = false;
		// capture Image
		BufferedImage screenshot = ActionRobot.doScreenShot();

		// process image
		Vision vision = new Vision(screenshot);
		VisionMBR visionMBR = new VisionMBR(screenshot);
		// find the slingshot
		Rectangle sling = vision.findSlingshotMBR();

		// confirm the slingshot
		while (sling == null && aRobot.getState() == GameState.PLAYING) {
			System.out.println("No slingshot detected. Please remove pop up or zoom out");
			ActionRobot.fullyZoomOut();
			screenshot = ActionRobot.doScreenShot();
			vision = new Vision(screenshot);
			sling = vision.findSlingshotMBR();
		}

		List<Rectangle> red_birds = visionMBR.findRedBirdsMBRs();
		List<Rectangle> blue_birds = visionMBR.findBlueBirdsMBRs();
		List<Rectangle> yellow_birds = visionMBR.findYellowBirdsMBRs();
		List<Rectangle> stone = visionMBR.findStonesMBR();
		List<Rectangle> ice = visionMBR.findIceMBR();
		List<Rectangle> wood = visionMBR.findWoodMBR();
		List<Rectangle> piggs = visionMBR.findPigsMBR();
		Analysis weakSpotAnalysis = new Analysis();
		weakSpotAnalysis.addWoodenObstacles(wood);
		weakSpotAnalysis.addIceObstacles(ice);
		weakSpotAnalysis.addStoneObstacles(stone);
		weakSpotAnalysis.addPigs(piggs);

		//GameState state = aRobot.checkState();
        // get all the pigs
 		List<ABObject> pigs = vision.findPigsMBR();
        List<ABObject> hill = vision.findHills();

		List<ABObject> blocks = vision.findBlocksMBR();
        List<ABObject> block = vision.findBlocksRealShape();
        List<ABObject> tnt = vision.findTNTs();
        ArrayList<ABObject> allObjects = new ArrayList<ABObject>();
        GameState state = aRobot.getState();

		// if there is a sling, then play, otherwise just skip.
		if (sling != null) {
			int flaground = 0;
			if (!pigs.isEmpty()) {

				Point releasePoint = null;
				Shot shot = new Shot();
				Shot shot1= new Shot();
				Shot shot2= new Shot();
				int dx = 0;
				int dy = 0;
				{
					// random pick up a pig
					//ABObject pig = pigs.get(randomGenerator.nextInt(pigs.size()));
                    for(int i=0;i<hill.size();i++){
                        ABObject h=hill.get(i);
                        //System.out.println("hill id : "+h.id+" hill type : "+h.type+" hill shape : "+h.shape);

                    }
                    for(int i=0;i<block.size();i++){
                        ABObject b=block.get(i);
                        //System.out.println(" block id "+b.id+" block type: "+b.type+" block shape : "+b.shape);

                    }

                    for(int i=0;i<tnt.size();i++){
                        ABObject t=tnt.get(i);
                        //System.out.println("tnt id : "+t.id+" tnt type : "+t.type+" tnt shape : "+t.shape);

                    }

                    //allObjects.addAll(hill);
                    allObjects.addAll(block);
                    ///allObjects.addAll(tnt);

                    //System.out.println("hi");
                    int max = pigs.get(0).getCenter2Y();
                    ABObject pig=pigs.get(0);
                    float value = (1068-pig.getCenter2Y())-(pig.getCenter2X()/2);
                    //System.out.println(value);
                    for(int i =1; i<pigs.size(); i++){
                        ABObject piggy = pigs.get(i);
                        float temp = (1068-piggy.getCenter2Y())-(piggy.getCenter2X()/2);
                       // System.out.println(temp);
                        if(temp > value){
                        	//System.out.println("inside if   ");
                        	value = temp;
                        	pig = piggy;
                        }
                    }

                    //System.out.println("y" + pig.getCenter2Y());
                    //System.out.println("x" + pig.getCenter2X());
 					/*ArrayList<ABObject> leftofpig = new ArrayList<ABObject>();
 					ArrayList<ABObject> rightofpig = new ArrayList<ABObject>();
 					ArrayList<ABObject> topofpig = new ArrayList<ABObject>();
 					ArrayList<ABObject> bottomofpig = new ArrayList<ABObject>();

                    for(int i = 0; i<allObjects.size(); i++){
                    	ABObject blk = allObjects.get(i);
                    	if((blk.getCenter2Y() - pig.getCenter2Y() < 15 || pig.getCenter2Y() - blk.getCenter2Y() < 15)&& pig.getCenter2X() - blk.getCenter2X() < 50 )
                    		leftofpig.add(blk);
                    	if((blk.getCenter2Y() - pig.getCenter2Y() < 15 || pig.getCenter2Y() - blk.getCenter2Y() < 15) && blk.getCenter2X() - pig.getCenter2X() < 50 )
               				rightofpig.add(blk);
               			if((blk.getCenter2X() - pig.getCenter2X() < 15 || pig.getCenter2X() - blk.getCenter2X() < 15) && pig.getCenter2Y() - blk.getCenter2Y() < 50 )
                    		topofpig.add(blk);
                    	if((blk.getCenter2X() - pig.getCenter2X() < 15 || pig.getCenter2X() - blk.getCenter2X() < 15) && blk.getCenter2Y() - pig.getCenter2Y() < 50 )
                    		bottomofpig.add(blk);	
                    }*/	
                    /*System.out.println("Left");
                    for( int i = 0; i<leftofpig.size(); i++){
                    	ABObject blk = leftofpig.get(i);
                    	System.out.println("ID:" + blk.id + "TYPE:" + blk.type);
                    } 
                    System.out.println("Right");
                    for( int i = 0; i<rightofpig.size(); i++){
                    	ABObject blk = rightofpig.get(i);
                    	System.out.println("ID:" + blk.id + "TYPE:" + blk.type);
                    } 
                    System.out.println("Top");
                    for( int i = 0; i<topofpig.size(); i++){
                    	ABObject blk = topofpig.get(i);
                    	System.out.println("ID:" + blk.id + "TYPE:" + blk.type);
                    } 
                    System.out.println("Bottom");
                    for( int i = 0; i<bottomofpig.size(); i++){
                    	ABObject blk = bottomofpig.get(i);
                    	System.out.println("ID:" + blk.id + "TYPE:" + blk.type);
                    } 
					*/
                    
                    //System.out.println("hello final"+pig.getCenter2X()+"  "+pig.getCenter2Y());
                    
                    Point _tpt;
                    switch(aRobot.getBirdTypeOnSling()){
                    case YellowBird:
                    _tpt = pig.getCenter();
                    break;

                    default:
					List<Point> weakSpots = weakSpotAnalysis.weakSpotsForRedBird();
					_tpt = weakSpots.get(0);
					break;
					}

					ABObject target_block = new ABObject();
					if(firstShot)
					{
						List<ABObject> realBlocks = vision.findBlocksRealShape();
						for(ABObject obj: realBlocks)
						{
							if((obj.shape == ABShape.Circle) && (obj.type == ABType.Stone || obj.type == ABType.Wood)) 
							{
								if(ABUtil.getSupporters(obj, blocks).size() == 0) 
								{
									target_block = obj;
									_tpt = target_block.getCenter();
								    flaground = 1;
									System.out.println("\nRound target id: " + obj.id + " type: " + obj.type + " shape:" + obj.shape);
									break;
								}
							}
						}
					}


					if (prevTarget != null && distance(prevTarget, _tpt) < 5) 
					{
						double _angle = randomGenerator.nextDouble() * Math.PI * 2;
						_tpt.x = _tpt.x + (int) (Math.cos(_angle) * 10);
						_tpt.y = _tpt.y + (int) (Math.sin(_angle) * 10);
						System.out.println("Randomly changing to " + _tpt);
					}

					prevTarget = new Point(_tpt.x, _tpt.y);

					// estimate the trajectory
					ArrayList<Point> pts = tp.estimateLaunchPoint(sling, _tpt);
                    System.out.println("size of pts" + pts.size());
					if(!pts.isEmpty())
						releasePoint = pts.get(0);
					// do a high shot when entering a level to find an accurate velocity
					//if (firstShot && pts.size() > 1) 
					//{
					//	releasePoint = pts.get(0);
					//}
					//else if (pts.size() == 1)
					//	releasePoint = pts.get(0);
					//else if (pts.size() == 2)
					//{
						// randomly choose between the trajectories, with a 1 in
						// 6 chance of choosing the high one
						//if ((randomGenerator.nextInt(6)) == 0)
					//		releasePoint = pts.get(0);
						//else
						//	releasePoint = pts.get(0);

                   // releasePoint=pts.get(1);
                    //}
					
					if(pts.isEmpty())
					{
						System.out.println("No release point found for the target");
						System.out.println("Try a shot with 45 degree");
						releasePoint = tp.findReleasePoint(sling, Math.PI/4);
					}
					
					// Get the reference point
					Point refPoint = tp.getReferencePoint(sling);


					//Calculate the tapping time according the bird type 
					if (releasePoint != null) {
						int tapInterval = 0;
						/*switch (aRobot.getBirdTypeOnSling()) 
						{

						case RedBird:
							tapInterval = 0; break;               // start of trajectory
						case YellowBird:
							tapInterval = 75 + randomGenerator.nextInt(5);break; // 65-90% of the way
						case WhiteBird:
							tapInterval =  70 + randomGenerator.nextInt(20);break; // 70-90% of the way
						case BlackBird:
							tapInterval =  70 + randomGenerator.nextInt(20);break; // 70-90% of the way
						case BlueBird:
							tapInterval =  75 + randomGenerator.nextInt(2);break; // 65-85% of the way
						default:
							tapInterval =  60;
						}*/
						
						ABUtil abu =  new ABUtil();
						int tapTime;
						if(pts.size()>1){
							int tapTime1;
							int tapTime2;
							int dy1;
							int dy2;
							int dx2;
							int dx1;						
							switch (aRobot.getBirdTypeOnSling()) {
							/*case YellowBird:
							tapInterval = 75 + randomGenerator.nextInt(5); // 65-90% of the way
							tapTime1 = tp.getTapTime(sling, pts.get(0), _tpt, tapInterval);
							dx1 = (int)(pts.get(0)).getX() - refPoint.x;
							dy1 = (int)(pts.get(0)).getY() - refPoint.y;
							shot1 = new Shot(refPoint.x, refPoint.y, dx1, dy1, 0, tapTime1);
							tapTime2 = tp.getTapTime(sling, pts.get(1), _tpt, tapInterval);
							dx2 = (int)(pts.get(1)).getX() - refPoint.x;
							dy2 = (int)(pts.get(1)).getY() - refPoint.y;
							shot2 = new Shot(refPoint.x, refPoint.y, dx2, dy2, 0, tapTime2);
							break;*/
							

							case RedBird:
							tapTime1 = tp.getTapTime(sling, pts.get(0), _tpt, tapInterval);
							dx1 = (int)(pts.get(0)).getX() - refPoint.x;
							dy1 = (int)(pts.get(0)).getY() - refPoint.y;
							shot1 = new Shot(refPoint.x, refPoint.y, dx1, dy1, 0, tapTime1);
							tapTime2 = tp.getTapTime(sling, pts.get(1), _tpt, tapInterval);
							dx2 = (int)(pts.get(1)).getX() - refPoint.x;
							dy2 = (int)(pts.get(1)).getY() - refPoint.y;
							shot2 = new Shot(refPoint.x, refPoint.y, dx2, dy2, 0, tapTime2);
							break;
							
							default:
							tapTime1 = FindTapInterval(screenshot, pts.get(0),sling, _tpt );
							dx1 = (int)(pts.get(0)).getX() - refPoint.x;
							dy1 = (int)(pts.get(0)).getY() - refPoint.y;
							shot1 = new Shot(refPoint.x, refPoint.y, dx1, dy1, 0, tapTime1);
							tapTime2 = FindTapInterval(screenshot, pts.get(1),sling, _tpt );
							dx2 = (int)(pts.get(1)).getX() - refPoint.x;
							dy2 = (int)(pts.get(1)).getY() - refPoint.y;
							shot2 = new Shot(refPoint.x, refPoint.y, dx2, dy2, 0, tapTime2);
							}
							//System.out.println("getting in");
							if(flaground == 1){
								//System.out.println("round case");
								shot = shot2;
								dx = dx2;
								dy = dy2;
								tapTime = tapTime2;
								releasePoint = pts.get(1);
							}
							else if(abu.isReachable(vision,_tpt,shot1)){
								System.out.println("bottom");
								shot = shot1;
								dx = dx1;
								dy = dy1;
								tapTime = tapTime1;
								releasePoint = pts.get(0);
							}
							else if(abu.isReachable(vision,_tpt,shot1)){
								System.out.println("top");
								shot = shot2;
								dx = dx2;
								dy = dy2;
								tapTime = tapTime2;
								releasePoint = pts.get(1);
							}
							else if(firstShot){
								//System.out.println("firstshot");
								shot = shot1;
								dx = dx1;
								dy = dy1;
								tapTime = tapTime1;
								releasePoint = pts.get(0);
							}

							/*else if(distance(prevTarget, _tpt) == 0){
								System.out.println("no change --> top");
								shot = shot2;
								dx = dx2;
								dy = dy2;
								tapTime = tapTime2;
								releasePoint = pts.get(0);
							}*/
							else {
                                System.out.println("random highs and lows");
                                int k = randomGenerator.nextInt(2);
                                if (k == 1){
                                    //System.out.println("low");
                                    shot = shot1;
                                    dx = dx1;
                                    dy1 = dy1;
                                    tapTime = tapTime1;
                                    releasePoint = pts.get(0);
                                }
                                else {
                                    //System.out.println("high");
                                    shot = shot2;
                                    dx = dx2;
                                    dy1 = dy2;
                                    tapTime = tapTime2;
                                    releasePoint = pts.get(1);
                                }    
                            }
							
							

						}	
						else
						{	
							switch(aRobot.getBirdTypeOnSling()){			
							case RedBird:			
							tapTime =tp.getTapTime(sling, pts.get(0), _tpt, tapInterval);
							dx = (int)releasePoint.getX() - refPoint.x;
							dy = (int)releasePoint.getY() - refPoint.y;	
							shot = new Shot(refPoint.x, refPoint.y, dx, dy, 0, tapTime);
							break;

							default:
							tapTime = FindTapInterval(screenshot, pts.get(0),sling, _tpt );
							dx = (int)releasePoint.getX() - refPoint.x;
							dy = (int)releasePoint.getY() - refPoint.y;	
							shot = new Shot(refPoint.x, refPoint.y, dx, dy, 0, tapTime);
							break;
						}
						}

						double releaseAngle = tp.getReleaseAngle(sling,
								releasePoint);
						System.out.println("Release Point: " + releasePoint);
						System.out.println("Release Angle: "
								+ Math.toDegrees(releaseAngle));
						
					}

					else
						{
							System.err.println("No Release Point Found");
							return state;
						}
				}

				// check whether the slingshot is changed. the change of the slingshot indicates a change in the scale.
				{
					ActionRobot.fullyZoomOut();
					screenshot = ActionRobot.doScreenShot();
					vision = new Vision(screenshot);
					Rectangle _sling = vision.findSlingshotMBR();
					if(_sling != null)
					{
						double scale_diff = Math.pow((sling.width - _sling.width),2) +  Math.pow((sling.height - _sling.height),2);
						if(scale_diff < 25)
						{
							if(dx < 0)
							{
								aRobot.cshoot(shot);
								state = aRobot.getState();
								if ( state == GameState.PLAYING )
								{
									screenshot = ActionRobot.doScreenShot();
									vision = new Vision(screenshot);
									List<Point> traj = vision.findTrajPoints();
									tp.adjustTrajectory(traj, sling, releasePoint);
									firstShot = false;
								}
							}
						}
						else
							System.out.println("Scale is changed, can not execute the shot, will re-segement the image");
					}
					else
						System.out.println("no sling detected, can not execute the shot, will re-segement the image");
				}

			}

		}
		return state;
	}

	public static void main(String args[]) {

		NaiveAgent na = new NaiveAgent();
		if (args.length > 0)
			na.currentLevel = Integer.parseInt(args[0]);
		a=0;
        na.run();

	}
}
